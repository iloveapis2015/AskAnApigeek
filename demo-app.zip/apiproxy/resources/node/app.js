/*eslint no-console:0*/

var express = require('express'),
	app = express(),
	path = require('path')
	//compress = require('compression');

app.use(express.static(path.join(__dirname, 'public')));
console.log('running...')
app.listen(9000);